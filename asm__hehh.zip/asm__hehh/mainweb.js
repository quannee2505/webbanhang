window.addEventListener('scroll', function() {
    var header = document.querySelector('.header');
    var bannerHeight = document.querySelector('.box').offsetHeight; // Chiều cao của banner
    var scrollPosition = window.scrollY;

    if (scrollPosition > bannerHeight / 2) { // Nếu vị trí cuộn lớn hơn nửa chiều cao của banner
        header.classList.add('header--scroll'); // Thêm lớp header--scroll
    } else {
        header.classList.remove('header--scroll'); // Loại bỏ lớp header--scroll
    }
});
// Lấy phần tử menu và nút menu
var menu = document.querySelector('.menu');
var menuBtn = document.getElementById('menu-btn');

// Thêm sự kiện click cho nút menu
menuBtn.addEventListener('click', function() {
    menu.classList.toggle('active'); // Thêm hoặc loại bỏ lớp 'active' khi nút menu được nhấp
});

// Thêm sự kiện click cho body
document.body.addEventListener('click', function(event) {
    // Kiểm tra xem sự kiện click có xảy ra trên menu hay không
    if (!menu.contains(event.target) && !menuBtn.contains(event.target)) {
        menu.classList.remove('active'); // Đóng menu nếu click ra ngoài menu và nút menu
    }
});

var scrollToTopBtn = document.getElementById("scrollToTopBtn");

// Thêm sự kiện lắng nghe cuộn trang
window.addEventListener("scroll", function() {
    // Kiểm tra vị trí cuộn của trang
    if (window.pageYOffset > window.innerHeight / 2) {
        // Hiển thị nút Scroll to Top khi cuộn trang tới nửa trang dưới
        scrollToTopBtn.style.display = "block";
    } else {
        // Ẩn nút Scroll to Top khi cuộn trang lên trên nửa trang dưới
        scrollToTopBtn.style.display = "none";
    }
});


function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}
// JavaScript để điều khiển hiển thị ẩn của giỏ hàng khi nhấp vào chữ "Giỏ hàng"
document.getElementById('cartLink').addEventListener('click', function(event) {
    event.preventDefault(); // Ngăn chặn hành động mặc định của liên kết
    var cart = document.getElementById('cart');
    // Nếu giỏ hàng đã được hiển thị, ẩn nó đi. Ngược lại, hiển thị nó.
    if (cart.style.display === 'block') {
        cart.style.display = 'none';
    } else {
        cart.style.display = 'block';
    }
});
// Lấy thẻ button bằng id
var closeCartBtn = document.getElementById("closeCartBtn");

// Thêm sự kiện click cho nút đóng
closeCartBtn.addEventListener("click", function() {
    var cart = document.getElementById("cart");
    cart.style.display = "none"; // Ẩn giỏ hàng khi click vào nút đóng
});
var accountLink = document.getElementById('dangnhap');

// Lấy form đăng nhập
var loginForm = document.getElementById('loginForm');

// Thêm sự kiện click cho thẻ <a>
accountLink.addEventListener('click', function(event) {
    // Ngăn chặn hành vi mặc định của thẻ <a>
    event.preventDefault();

    // Toggle lớp hiển thị cho form đăng nhập
    loginForm.classList.toggle('show');
});

document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector('.login-form');
    const usernameInput = document.querySelector('#username');
    const passwordInput = document.querySelector('#password');
    const submitButton = document.querySelector('.login-form button[type="submit"]');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Ngăn chặn gửi form
        
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();
        
       // Kiểm tra tên người dùng và mật khẩu
if (username === 'admin' && password === 'admin') {
    // Ẩn form
    document.getElementById('loginForm').style.display = 'none';
    
    // Hiển thị thông báo đăng nhập thành công
    alert('Đăng nhập thành công!');

} else {
    // Hiển thị thông báo lỗi
    alert('Tên người dùng hoặc mật khẩu không chính xác!');
}

    });
});


// Lấy tất cả các button "Thêm vào giỏ hàng"
const addToCartButtons = document.querySelectorAll('.themvaogio');

// Function thêm sản phẩm vào giỏ hàng và kích hoạt hiệu ứng
function addToCart(event) {
    const button = event.target;
    const product = button.closest('.produc__item'); // Tìm phần tử cha gần nhất có class "produc__item"
    product.classList.add('add-to-cart-animation'); // Thêm class mới để kích hoạt hiệu ứng
    setTimeout(() => {
        product.classList.remove('add-to-cart-animation'); // Loại bỏ class sau khi hiệu ứng hoàn thành
    }, 500); // Đảm bảo thời gian của hiệu ứng khớp với thời gian của animation trong CSS
}

// Lặp qua từng button "Thêm vào giỏ hàng" và thêm sự kiện click
addToCartButtons.forEach(button => {
    button.addEventListener('click', addToCart);
});