window.addEventListener('scroll', function() {
    var header = document.querySelector('.header');
    var bannerHeight = document.querySelector('.banner').offsetHeight; // Chiều cao của banner
    var scrollPosition = window.scrollY;

    if (scrollPosition > bannerHeight / 2) { // Nếu vị trí cuộn lớn hơn nửa chiều cao của banner
        header.classList.add('header--scroll'); // Thêm lớp header--scroll
    } else {
        header.classList.remove('header--scroll'); // Loại bỏ lớp header--scroll
    }
});
// Lấy phần tử menu và nút menu
var menu = document.querySelector('.menu');
var menuBtn = document.getElementById('menu-btn');

// Thêm sự kiện click cho nút menu
menuBtn.addEventListener('click', function() {
    menu.classList.toggle('active'); // Thêm hoặc loại bỏ lớp 'active' khi nút menu được nhấp
});

// Thêm sự kiện click cho body
document.body.addEventListener('click', function(event) {
    // Kiểm tra xem sự kiện click có xảy ra trên menu hay không
    if (!menu.contains(event.target) && !menuBtn.contains(event.target)) {
        menu.classList.remove('active'); // Đóng menu nếu click ra ngoài menu và nút menu
    }
});
var scrollToTopBtn = document.getElementById("scrollToTopBtn");

// Thêm sự kiện lắng nghe cuộn trang
window.addEventListener("scroll", function() {
    // Kiểm tra vị trí cuộn của trang
    if (window.pageYOffset > window.innerHeight / 2) {
        // Hiển thị nút Scroll to Top khi cuộn trang tới nửa trang dưới
        scrollToTopBtn.style.display = "block";
    } else {
        // Ẩn nút Scroll to Top khi cuộn trang lên trên nửa trang dưới
        scrollToTopBtn.style.display = "none";
    }
});


function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Lấy tất cả các button có class "mua"
const buyButtons = document.querySelectorAll('.mua');

// Function thêm animation khi click vào nút mua
function animateBuyButton(event) {
    const button = event.target;
    button.style.animation = 'none'; // Đảm bảo không có animation nào được áp dụng trước khi bắt đầu animation mới
    button.offsetHeight; // Kích hoạt reflow để áp dụng style mới
    button.style.animation = 'buyAnimation 0.3s ease-in-out'; // Áp dụng animation mới
}

// Lặp qua từng button và thêm sự kiện click để gọi function animateBuyButton
buyButtons.forEach(button => {
    button.addEventListener('click', animateBuyButton);
});

// Lấy tất cả các button "Thêm vào giỏ hàng"
const addToCartButtons = document.querySelectorAll('.themvaogio');

// Function thêm sản phẩm vào giỏ hàng và kích hoạt hiệu ứng
function addToCart(event) {
    const button = event.target;
    const product = button.closest('.produc__item'); // Tìm phần tử cha gần nhất có class "produc__item"
    product.classList.add('add-to-cart-animation'); // Thêm class mới để kích hoạt hiệu ứng
    setTimeout(() => {
        product.classList.remove('add-to-cart-animation'); // Loại bỏ class sau khi hiệu ứng hoàn thành
    }, 500); // Đảm bảo thời gian của hiệu ứng khớp với thời gian của animation trong CSS
}

// Lặp qua từng button "Thêm vào giỏ hàng" và thêm sự kiện click
addToCartButtons.forEach(button => {
    button.addEventListener('click', addToCart);
});
